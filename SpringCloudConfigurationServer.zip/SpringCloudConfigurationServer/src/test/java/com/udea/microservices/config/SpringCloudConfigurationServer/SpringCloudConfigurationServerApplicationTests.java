package com.udea.microservices.config.SpringCloudConfigurationServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigurationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
